class Greeting1 {
    public static void greet(String name) {
        System.out.println("Salam, " + name + "Xoshgeldiniz.");
    }
}

public class Greeting {
    public static void main(String[] args) {
        Greeting.greet("Deneme");
    }
}
