class MathOperations {
    public int add(int a, int b, int c) {
        return a + b + c;
    }

}


public class Methods {
    public static void main(String[] args) {
        MathOperations mathops = new MathOperations();
        int result = mathops.add(5, 10, 15);
        System.out.println("Deneme: " + result);
    }
}
//Coded by ShoriuOfficial