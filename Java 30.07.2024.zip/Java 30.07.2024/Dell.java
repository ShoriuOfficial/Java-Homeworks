class Dell extends Computer {
    String specialFeature;

    public Dell(String brand, String model, String processor, int ram, String specialFeature) {
        super(brand, model, processor, ram);
        this.specialFeature = specialFeature;
    }

    public void displayDellFeature() {
        System.out.println("Dell Special Feature: " + specialFeature);
    }
}