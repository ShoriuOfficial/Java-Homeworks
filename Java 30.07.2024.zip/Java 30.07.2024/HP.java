class HP extends Computer {
    String warrantyPeriod;

    public HP(String brand, String model, String processor, int ram, String warrantyPeriod) {
        super(brand, model, processor, ram);
        this.warrantyPeriod = warrantyPeriod;
    }

    public void displayHPWarranty() {
        System.out.println("HP Warranty Period: " + warrantyPeriod);
    }
}