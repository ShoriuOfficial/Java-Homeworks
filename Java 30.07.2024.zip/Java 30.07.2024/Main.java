public class Main {
    public static void main(String[] args) {
        Dell dellComputer = new Dell("Dell", "XPS 15", "Intel i7", 16, "Fingerprint Scanner");
        HP hpComputer = new HP("HP", "Envy 13", "Intel i5", 8, "2 Years");

        System.out.println("Dell Computer Specifications:");
        dellComputer.displaySpecs();
        dellComputer.displayDellFeature();

        System.out.println("\nHP Computer Specifications:");
        hpComputer.displaySpecs();
        hpComputer.displayHPWarranty();
    }
}