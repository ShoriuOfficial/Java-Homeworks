class Computer {
    String brand;
    String model;
    String processor;
    int ram;

    public Computer(String brand, String model, String processor, int ram) {
        this.brand = brand;
        this.model = model;
        this.processor = processor;
        this.ram = ram;
    }

    public void displaySpecs() {
        System.out.println("Brand: " + brand + ", Model: " + model + ", Processor: " + processor + ", RAM: " + ram + "GB");
    }
}